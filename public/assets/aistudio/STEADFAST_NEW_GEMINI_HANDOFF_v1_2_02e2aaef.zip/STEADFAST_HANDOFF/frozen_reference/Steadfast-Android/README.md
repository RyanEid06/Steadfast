# Steadfast Android

> **Status:** Product/UI specification frozen for V1 implementation.
>
> **Product:** Offline Christian recovery + Bible progress tracker for Android.
>
> **Tagline:** *A stronger you. A closer walk with God.*

Steadfast treats two pillars as equal: **recovery/self-discipline** and **Bible progress**. It is not a pornography-only app. The user chooses one recovery focus from a curated list; pornography is one supported focus.

## V1 non-negotiables

- Native Android, Kotlin + Jetpack Compose.
- Fully offline. No account, no cloud, no analytics, no ads, no network dependency.
- Modern Android target; **minSdk 29** unless a concrete implementation blocker justifies a change.
- Three primary destinations only: **Dashboard / Journey / Bible**.
- **Settings is a top-level icon/control, not a fourth bottom-nav tab.**
- Dashboard is one fixed, no-scroll composition. It must adapt/reflow on small screens rather than requiring user scrolling.
- Exact recovery start **date + time**; live timer updates every second while Dashboard is visible.
- Streak history is preserved on restart and feeds a history chart.
- Journal supports arbitrary notes throughout the day and notes during restart/urge moments.
- Bible uses the **66-book Protestant canon** (1,189 chapters).
- Maximum two "Currently Reading" positions: one OT + one NT.
- No forced chronological reading. Completing a chapter does not automatically change current reading.
- One app-wide recovery streak. **No Bible streak.**
- Bible reading goal is a motivational target (1–5 chapters, rendered as e.g. `3+`) and is **not daily-completion-tracked** in V1 because chapter completion timestamps are intentionally not stored.
- Light + dark themes with cinematic, peaceful Christian styling.
- Biometric/device-credential app lock modeled after the proven SpendWise/Memora pattern.
- Versioned import/export backup file designed specifically for Steadfast.
- Home-screen widget, Duolingo-like at-a-glance progress, included in V1.
- No notifications.
- Screenshots are allowed.

## Start here

Gemini/implementation agents must read, in order:

1. `GEMINI.md`
2. `docs/PRODUCT_SPEC.md`
3. `docs/UI_SPEC.md`
4. `docs/ARCHITECTURE.md`
5. `docs/DATA_MODEL.md`
6. `docs/SECURITY_BACKUP.md`
7. `docs/DESIGN_FREEZE.md`
8. `docs/ACCEPTANCE_TESTS.md`
9. `prompts/00_MASTER_IMPLEMENTATION_PROMPT.md`

Visual references are in `design/mockups/`. The authoritative visual merge is `docs/DESIGN_FREEZE.md` plus `design/mockups/canonical/`. Do not treat any single full board as the final UI. If a mockup contradicts the written specification, **the written specification wins**.

## Important content-rights rule

The desired long-term verse library is 1,000+ curated verses, with NLT preferred. Do **not** bulk-copy or scrape NLT verse text into this repository or APK without appropriate rights. The repo ships reference/topic metadata only. Verse text may later be populated from a licensed source or text explicitly supplied by the project owner.
